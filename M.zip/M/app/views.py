from django.shortcuts import render,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.shortcuts import redirect, render
from .models import Employee

def index(request):
    return render(request, 'index.html')

def base(request):
    return render(request, 'base.html')


# def login(request):
#     if request.method == 'POST':
#         username = request.POST['user']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             auth_login(request, user)
#             return redirect('base')
        
#         return render(request, 'login.html', {'error_message': "Invalid username or password. Please try again."})
#     return render(request, 'login.html')


def login(request):
    if request.method == 'POST':
        username = request.POST.get('user')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            if user.is_superuser:
                return redirect('add')
            else:
                return redirect('base')
        else:
            error_message = "Invalid username or password. Please try again."
            return render(request, 'login.html', {'error_message': error_message})
    return render(request, 'login.html')


# from django.contrib.auth import authenticate, login as auth_login
# from django.shortcuts import render, redirect

# def login(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']

#         # Check if the user is an admin
#         admin = authenticate(request, username=username, password=password)
#         if admin is not None and admin.is_superuser:
#             auth_login(request, admin)
#             return redirect('add')

#         # Check if the user is a regular user
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             auth_login(request, user)
#             return redirect('base')

#         # Invalid login credentials
#         return render(request, 'login.html', {'error': 'Invalid username or password'})

#     return render(request, 'login.html')






def logout(request):
	request.session.clear()
	auth_logout(request)
	return redirect('login')

def register(request):
    if request.method=='POST':
        username = request.POST['username']
        email = request.POST['email']
        password='12345'
        user = User.objects.create_user(email=email, username=email, password=password)

        return render(request, 'register.html')
    else:
        return render(request,' register.html')
    
def add(request):
    if request.method == 'POST':
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        phone = request.POST['phone']
        email = request.POST['email']
        empid = request.POST['empid']
        emprole = request.POST['emprole']
        
        emp = Employee(firstname=firstname,lastname=lastname,phone=phone,email=email,empid=empid,emprole=emprole)
        emp.save()

        message = 'New Employee Added'
        context = {'message': message}
        return render(request, 'add.html',context)
    else:
        message = 'New Employee Added'
        context = {'message': message}
        return render(request, 'add.html',context)


def view(request):
    emps = Employee.objects.all()
    context = {'emps':emps}
    return render(request, 'view.html',context)


def edit(request,empid):
    emp = Employee.objects.get(id=empid)
    if request.method=='POST':
        emp.firstname = request.POST['firstname']
        emp.lastname = request.POST['lastname']
        emp.email = request.POST['email']
        emp.phone = request.POST['phone']
        emp.empid = request.POST['empid']
        emp.emprole = request.POST['emprole']
        emp.save()
        return redirect('add.html')
    context = {'emp': emp}
    return render(request, 'edit.html',context)

def delete(request, empid):
    emp = Employee.objects.get(id=empid)
    if request.method == 'POST':
        emp.delete()
        return redirect('add')  
    context = {'emp': emp}
    return render(request, 'delete.html', context)