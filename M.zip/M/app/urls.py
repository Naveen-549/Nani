
from django.contrib import admin
from django.urls import path
from.import views


urlpatterns = [
    path('', views.index, name='index'),
    path('login', views.login, name='login'),
    path('base', views.base, name='base'),
    path('add', views.add, name='add'),
    path('edit/<int:empid>/', views.edit, name='edit'),
    path('delete/<int:empid>/', views.delete, name='delete'),
    path('view', views.view, name='view'),
    path('logout',views.logout,name='logout'),
]
